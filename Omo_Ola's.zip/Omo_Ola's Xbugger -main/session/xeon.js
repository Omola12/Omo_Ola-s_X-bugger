{
	"name": "STAR MD Bot Multi Device "
}
